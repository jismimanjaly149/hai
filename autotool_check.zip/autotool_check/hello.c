#include<stdio.h>
int main()
{
printf("how r u\n");
}
